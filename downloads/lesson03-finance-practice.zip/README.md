# Lesson 03 — 금융 데이터 실습

sample.csv를 읽어 이동평균을 계산합니다.
