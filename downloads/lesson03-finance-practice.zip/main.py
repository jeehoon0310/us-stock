"""강의 03 — 금융 데이터 실습"""
import pandas as pd


df = pd.read_csv("sample.csv")
df["ma5"] = df["price"].rolling(5).mean()
print(df.tail())
