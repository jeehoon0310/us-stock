"""강의 02 — 데이터 분석 입문"""
import pandas as pd


def load_sample() -> pd.DataFrame:
    return pd.DataFrame({"x": [1, 2, 3], "y": [10, 20, 30]})


if __name__ == "__main__":
    print(load_sample().describe())
