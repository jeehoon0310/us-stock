# Lesson 02 — 데이터 분석 입문

- pandas DataFrame 기본 조작
- describe / groupby / merge
