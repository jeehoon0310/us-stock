"""강의 01 — 파이썬 기초 예제"""


def greet(name: str) -> str:
    return f"안녕하세요, {name}님!"


if __name__ == "__main__":
    for n in ["철수", "영희", "민수"]:
        print(greet(n))
